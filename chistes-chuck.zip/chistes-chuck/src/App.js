import './App.css';
import Body from './components/body/Body';

function App() {
  return (
    <>
      <Body />
    </>
  );
}

export default App;
